export class User {
    fullName: string; 
    password: string;
}