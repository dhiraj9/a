import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  login(data:any){
    return this.http.post<any>('http://localhost:3005/users/login',data);
  }
  register(data:any){
    return this.http.post<any>('http://localhost:3005/users/register',data);
  }
  account(data:any){
  var header:HttpHeaders=new HttpHeaders();
  header=header.append('x-auth',data);
  return this.http.get<any>('http://localhost:3005/users/account',{headers:header});
  }
  resetpwd(data,id,auth){
    var header:HttpHeaders=new HttpHeaders();
    header=header.append('x-auth',auth);
    return this.http.put('http://localhost:3005/users/reset/'+id,data,{headers:header});
  }
  info(auth){
    var header:HttpHeaders=new HttpHeaders();
    header=header.append('x-auth',auth);
    return this.http.get<any>('http://localhost:3005/users/info',{headers:header});
  }
  deleteuser(auth,id){
    var header:HttpHeaders=new HttpHeaders();
    header=header.append('x-auth',auth);
    return this.http.delete<any>('http://localhost:3005/users/'+id,{headers:header})
  }
  constructor(private http:HttpClient) { }
}
