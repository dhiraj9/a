import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from 'selenium-webdriver/http';
import { LoginService } from './services/login.service';
import { HttpClientModule } from '@angular/common/http';
import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { DisplayComponent } from './display/display.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ForgotpwdComponent,
    DisplayComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    AngularFontAwesomeModule
  ],
  providers: [FormBuilder, LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
