import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.css']
})
export class ForgotpwdComponent implements OnInit {
  registerForm:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private loginservice: LoginService) { }

    onSubmit(){
      this.submitted=true;
      if(this.registerForm.invalid){
        return;
      }
      let authkey=localStorage.getItem('authtoken');
      this.loginservice.account(authkey).subscribe(res=>{
        console.log(res);
        this.loginservice.resetpwd({confirm:this.registerForm.controls.newpassword.value,password:this.registerForm.controls.oldpassword.value,username:'ganapathy'},res._id,authkey).subscribe(res2=>{
          console.log(res2);
          
        });
      });
    }
    navtodisplay(){
      this.router.navigate(['./display']);
    }

    get f() { return this.registerForm.controls; }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      oldpassword: ['', [Validators.required, Validators.minLength(8),Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")]],
      newpassword: ['', [Validators.required, Validators.minLength(8),Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")]]
  });
  }

}
