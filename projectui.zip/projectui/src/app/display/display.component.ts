import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  tabledata:any[]=[]
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private loginservice: LoginService) { }

  ngOnInit() {
    let authkey=localStorage.getItem('authtoken');
      this.loginservice.account(authkey).subscribe(res=>{
        console.log(res.Admin);
        if(res.Admin){
          this.loginservice.info(authkey).subscribe(res2=>{
            for(let i=0;i<res2.length;i++){
              this.tabledata.push(res2[i]);
            }
            console.log(this.tabledata);
            
          })
        }
      });
  }
  deleteusr(ind){
    let authkey=localStorage.getItem('authtoken');
    let id=this.tabledata[ind]._id;
    this.loginservice.deleteuser(authkey,id).subscribe(
      res=>{
        this.tabledata.splice(ind,1);
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    )
  }

  logout(){
    localStorage.clear();
    this.router.navigate(['']);
  }

  resetpwd(){
    this.router.navigate(['/forgotpwd'])
  }

}
