import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private loginservice: LoginService) { }

    get f() { return this.registerForm.controls; }

    onSubmit(){
      this.submitted=true;
      if(this.registerForm.invalid){
        return;
      }
      this.loginservice.register(this.registerForm.value).subscribe(res=>{
        console.log(res);
        
      },err=>{
        console.log(err);
        
      });
    }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8),Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")]],
      Admin: [false]
  });
  }

}
