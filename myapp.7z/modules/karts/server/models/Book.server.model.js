'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Kart Schema
 */
var BookSchema = new Schema({
    imageUrl:String,
    title:String,
    price:String,
    author:String,
    rating:String,
    description:String
});

mongoose.model('books', BookSchema);
