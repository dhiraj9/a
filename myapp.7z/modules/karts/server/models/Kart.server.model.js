'use strict';

/**
* Module dependencies.
*/
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
* Kart Schema
*/
var KartSchema = new Schema({
    bookIds: {
        type: [{
             type:String,
             ref:'books'
        }]
      },
  user: {
    type: String,
    ref: 'User'
  }
});

mongoose.model('Kart', KartSchema);
