'use strict';

/**
 * Module dependencies
 */
var kartsPolicy = require('../policies/karts.server.policy'),
  karts = require('../controllers/karts.server.controller');

module.exports = function(app) {
  // Karts Routes
  app.route('/api/karts').all(kartsPolicy.isAllowed)
    .get(karts.list)
    .post(karts.create);

  app.route('/api/karts/:bookid').all(kartsPolicy.isAllowed)
    .get(karts.read)
    .put(karts.update)
    .delete(karts.delete);

  app.route('/api/kartbooks').all(kartsPolicy.isAllowed).get(karts.books);

  // Finish by binding the Kart middleware
   app.param('kartId', karts.kartByID);
   
};
