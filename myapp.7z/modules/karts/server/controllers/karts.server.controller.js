'use strict';

/**
 * Module dependencies.
 */
var path = require('path'),
  mongoose = require('mongoose'),
  Book = mongoose.model('books'),
  Kart=mongoose.model('Kart'),
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller')),
  _ = require('lodash');

/**
 * Create a Kart
 */
exports.create = function(req, res) {
  var kart = new Kart(req.body);
  kart.user = req.user;

  kart.save(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.jsonp(kart);
    }
  });
};

/**
 * Show the current Kart
 */
exports.read = function(req, res) {
  // convert mongoose document to JSON
  // var kart = req.kart ? req.kart.toJSON() : {};

  // Add a custom field to the Article, for determining if the current User is the "owner".
  // NOTE: This field is NOT persisted to the database, since it doesn't exist in the Article model.
  // kart.isCurrentUserOwner = req.user && kart.user && kart.user._id.toString() === req.user._id.toString();

  // res.jsonp(kart);
  Book.findById(req.params.bookid,function(err,book){
    if(err){
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
    });
  }
    else{
      res.jsonp(book);
    }

  });
};

/**
 * Update a Kart
 */
exports.update = function(req, res) {
  var user=req.user;
  
  Kart.update({"user":user._id},{$push:{bookIds:req.params.bookid},"user":user._id},{ upsert: true }).then(function(result){
    console.log("added book to kart");
})
  
  
  
};

/**
 * Delete an Kart
 */
exports.delete = function(req, res) {
  var kart = req.kart;

  kart.remove(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.jsonp(kart);
    }
  });
};

/**
 * List of Karts
 */
exports.list = function(req, res) {
  Book.find(function(err,book){
    if(err) res.send(err);
    else  res.jsonp(book);
    });
};

exports.books=function(req,res){
   Kart.find({'user':req.user._id}).then(function(result){
    return res.jsonp(result);
  }) 
};


/**
 * Kart middleware
 */
exports.kartByID = function(req, res,next,id) {

   if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).send({
      message: 'Kart is invalid'
    });
  }

 

  Kart.findById(id).populate('user', 'displayName').exec(function (err, kart) {
    if (err) {
      return next(err);
    } else if (!kart) {
      return res.status(404).send({
        message: 'No Kart with that identifier has been found'
      });
    }
    req.kart = kart;
    next(); 
  }); 

};
