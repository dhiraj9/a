(function () {
  'use strict';

  // Karts controller
  angular
    .module('karts')
    .controller('KartsController', KartsController);

  KartsController.$inject = ['$scope', '$state', '$window', 'Authentication','KartsResolve'];

  function KartsController ($scope, $state, $window, Authentication,kart) {
    var vm = this;

    vm.authentication = Authentication;
    vm.kart = kart;
    vm.error = null;
    vm.form = {};
    vm.remove = remove;
    vm.save = save;
   

    // Remove existing Kart
     function remove() {
      if ($window.confirm('Are you sure you want to delete?')) {
        vm.kart.$remove($state.go('karts.list'));
      }
    } 

    // Save Kart
     function save(isValid) {
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'vm.form.kartForm');
        return false;
      } 

      // TODO: move create/update logic to service
      if (vm.kart._id) {
        vm.kart.$update(successCallback, errorCallback);
      } else {
        vm.kart.$save(successCallback, errorCallback);
      }

      function successCallback(res) {
        $state.go('karts.view', {
          kartId: res._id
        });
      }

      function errorCallback(res) {
        vm.error = res.data.message;
      }
    }
     
   
  }
}());
