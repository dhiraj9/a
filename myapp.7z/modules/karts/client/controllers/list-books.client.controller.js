(function () {
  'use strict';

  angular
    .module('karts')
    .controller('BooksListController', BooksListController);

    BooksListController.$inject = ['KartsService','$scope','$http'];

  function BooksListController(KartsService,$scope,$http) {
    var vm = this;
  
     vm.karts = KartsService.query();
   
     $scope.saveBook=function(bookid){ 
     $http.put('/api/karts/'+bookid);   
      }  
    
  }
}());
