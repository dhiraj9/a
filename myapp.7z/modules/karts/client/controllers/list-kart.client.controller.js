(function () {
    'use strict';
  
    angular
      .module('karts')
      .controller('KartsListController', KartsListController);
  
    KartsListController.$inject = ['KartsService','$scope','$http'];
  
    function KartsListController(KartsService,$scope,$http) {
      var vm = this;
      
      vm.kartbooks=[];
       
      $http.get('/api/kartbooks').then(function(res){
        vm.bookIds=res.data[0].bookIds;
        
        for(var i=0;i<vm.bookIds.length;i++){
          
          $http.get('/api/karts/'+vm.bookIds[i]).then(function(res){
       
              vm.kartbooks.push(res.data);
            
            })
          }
  
      })
      
    }
  }());
  