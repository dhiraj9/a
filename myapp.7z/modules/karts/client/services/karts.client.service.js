// Karts service used to communicate Karts REST endpoints
(function () {
  'use strict';

  angular
    .module('karts')
    .factory('KartsService', KartsService);

  KartsService.$inject = ['$resource'];

  function KartsService($resource) {
     return $resource('api/karts/:kartId', {
      kartId: '@_id'
    }, {
      update: {
        method: 'PUT'
      }
    });  
  } 
}());
