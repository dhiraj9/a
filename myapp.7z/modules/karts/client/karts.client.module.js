(function (app) {
  'use strict';

  app.registerModule('karts');
}(ApplicationConfiguration));
