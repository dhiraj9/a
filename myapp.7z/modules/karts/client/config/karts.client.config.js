(function () {
  'use strict';

  angular
    .module('karts')
    .run(menuConfig);

  menuConfig.$inject = ['Menus'];

  function menuConfig(menuService) {
    // Set top bar menu items
    menuService.addMenuItem('topbar', {
      title: 'Books',
      state: 'karts',
      type: 'dropdown',
      roles: ['*']
    });

    // Add the dropdown list item
    menuService.addSubMenuItem('topbar', 'karts', {
      title: 'List of Books',
      state: 'karts.list'
    });

    // Add the dropdown create item
    menuService.addSubMenuItem('topbar', 'karts', {
      title: 'Kart',
      state: 'karts.view',
      roles: ['user']
    });
  }
}());
