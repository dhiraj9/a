(function () {
  'use strict';

  angular
    .module('karts')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('karts', {
        abstract: true,
        url: '',
        template: '<ui-view/>'
      })
      .state('karts.list', {
        url: '/books',
        templateUrl: 'modules/karts/client/views/list-karts.client.view.html',
        controller: 'BooksListController',
        controllerAs: 'vm',
        data: {
          pageTitle: 'Karts List'
        }
      })
      .state('karts.create', {
        url: '/create',
        templateUrl: 'modules/karts/client/views/form-kart.client.view.html',
        controller: 'KartsController',
        controllerAs: 'vm',
        resolve: {
          kartResolve: newKart
        },
        data: {
          roles: ['user', 'admin'],
          pageTitle: 'Karts Create'
        }
      })
      .state('karts.edit', {
        url: '/:kartId/edit',
        templateUrl: 'modules/karts/client/views/form-kart.client.view.html',
        controller: 'KartsController',
        controllerAs: 'vm',
        resolve: {
          kartResolve: getKart
        },
        data: {
          roles: ['user', 'admin'],
          pageTitle: 'Edit Kart {{ kartResolve.name }}'
        }
      })
      .state('karts.view', {
        url: '/kart',
        templateUrl: 'modules/karts/client/views/view-kart.client.view.html',
        controller: 'KartsListController',
        controllerAs: 'vm',
        /*  resolve: {
          kartResolve: getKart
        },   */
        data: {
         //pageTitle: 'Kart {{ kartResolve.name }}'
          pageTitle:'Karts View'
        }
      });
  }

  getKart.$inject = ['$stateParams', 'KartsService'];

  function getKart($stateParams, KartsService) {
    return KartsService.get({
      kartId: $stateParams.kartId
    }).$promise;
  }

  newKart.$inject = ['KartsService'];

  function newKart(KartsService) {
    return new KartsService();
  }
}());
