'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Kart = mongoose.model('Kart'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app,
  agent,
  credentials,
  user,
  kart;

/**
 * Kart routes tests
 */
describe('Kart CRUD tests', function () {

  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      username: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      username: credentials.username,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new Kart
    user.save(function () {
      kart = {
        name: 'Kart name'
      };

      done();
    });
  });

  it('should be able to save a Kart if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new Kart
        agent.post('/api/karts')
          .send(kart)
          .expect(200)
          .end(function (kartSaveErr, kartSaveRes) {
            // Handle Kart save error
            if (kartSaveErr) {
              return done(kartSaveErr);
            }

            // Get a list of Karts
            agent.get('/api/karts')
              .end(function (kartsGetErr, kartsGetRes) {
                // Handle Karts save error
                if (kartsGetErr) {
                  return done(kartsGetErr);
                }

                // Get Karts list
                var karts = kartsGetRes.body;

                // Set assertions
                (karts[0].user._id).should.equal(userId);
                (karts[0].name).should.match('Kart name');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an Kart if not logged in', function (done) {
    agent.post('/api/karts')
      .send(kart)
      .expect(403)
      .end(function (kartSaveErr, kartSaveRes) {
        // Call the assertion callback
        done(kartSaveErr);
      });
  });

  it('should not be able to save an Kart if no name is provided', function (done) {
    // Invalidate name field
    kart.name = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new Kart
        agent.post('/api/karts')
          .send(kart)
          .expect(400)
          .end(function (kartSaveErr, kartSaveRes) {
            // Set message assertion
            (kartSaveRes.body.message).should.match('Please fill Kart name');

            // Handle Kart save error
            done(kartSaveErr);
          });
      });
  });

  it('should be able to update an Kart if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new Kart
        agent.post('/api/karts')
          .send(kart)
          .expect(200)
          .end(function (kartSaveErr, kartSaveRes) {
            // Handle Kart save error
            if (kartSaveErr) {
              return done(kartSaveErr);
            }

            // Update Kart name
            kart.name = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing Kart
            agent.put('/api/karts/' + kartSaveRes.body._id)
              .send(kart)
              .expect(200)
              .end(function (kartUpdateErr, kartUpdateRes) {
                // Handle Kart update error
                if (kartUpdateErr) {
                  return done(kartUpdateErr);
                }

                // Set assertions
                (kartUpdateRes.body._id).should.equal(kartSaveRes.body._id);
                (kartUpdateRes.body.name).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a list of Karts if not signed in', function (done) {
    // Create new Kart model instance
    var kartObj = new Kart(kart);

    // Save the kart
    kartObj.save(function () {
      // Request Karts
      request(app).get('/api/karts')
        .end(function (req, res) {
          // Set assertion
          res.body.should.be.instanceof(Array).and.have.lengthOf(1);

          // Call the assertion callback
          done();
        });

    });
  });

  it('should be able to get a single Kart if not signed in', function (done) {
    // Create new Kart model instance
    var kartObj = new Kart(kart);

    // Save the Kart
    kartObj.save(function () {
      request(app).get('/api/karts/' + kartObj._id)
        .end(function (req, res) {
          // Set assertion
          res.body.should.be.instanceof(Object).and.have.property('name', kart.name);

          // Call the assertion callback
          done();
        });
    });
  });

  it('should return proper error for single Kart with an invalid Id, if not signed in', function (done) {
    // test is not a valid mongoose Id
    request(app).get('/api/karts/test')
      .end(function (req, res) {
        // Set assertion
        res.body.should.be.instanceof(Object).and.have.property('message', 'Kart is invalid');

        // Call the assertion callback
        done();
      });
  });

  it('should return proper error for single Kart which doesnt exist, if not signed in', function (done) {
    // This is a valid mongoose Id but a non-existent Kart
    request(app).get('/api/karts/559e9cd815f80b4c256a8f41')
      .end(function (req, res) {
        // Set assertion
        res.body.should.be.instanceof(Object).and.have.property('message', 'No Kart with that identifier has been found');

        // Call the assertion callback
        done();
      });
  });

  it('should be able to delete an Kart if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new Kart
        agent.post('/api/karts')
          .send(kart)
          .expect(200)
          .end(function (kartSaveErr, kartSaveRes) {
            // Handle Kart save error
            if (kartSaveErr) {
              return done(kartSaveErr);
            }

            // Delete an existing Kart
            agent.delete('/api/karts/' + kartSaveRes.body._id)
              .send(kart)
              .expect(200)
              .end(function (kartDeleteErr, kartDeleteRes) {
                // Handle kart error error
                if (kartDeleteErr) {
                  return done(kartDeleteErr);
                }

                // Set assertions
                (kartDeleteRes.body._id).should.equal(kartSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to delete an Kart if not signed in', function (done) {
    // Set Kart user
    kart.user = user;

    // Create new Kart model instance
    var kartObj = new Kart(kart);

    // Save the Kart
    kartObj.save(function () {
      // Try deleting Kart
      request(app).delete('/api/karts/' + kartObj._id)
        .expect(403)
        .end(function (kartDeleteErr, kartDeleteRes) {
          // Set message assertion
          (kartDeleteRes.body.message).should.match('User is not authorized');

          // Handle Kart error error
          done(kartDeleteErr);
        });

    });
  });

  it('should be able to get a single Kart that has an orphaned user reference', function (done) {
    // Create orphan user creds
    var _creds = {
      username: 'orphan',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create orphan user
    var _orphan = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'orphan@test.com',
      username: _creds.username,
      password: _creds.password,
      provider: 'local'
    });

    _orphan.save(function (err, orphan) {
      // Handle save error
      if (err) {
        return done(err);
      }

      agent.post('/api/auth/signin')
        .send(_creds)
        .expect(200)
        .end(function (signinErr, signinRes) {
          // Handle signin error
          if (signinErr) {
            return done(signinErr);
          }

          // Get the userId
          var orphanId = orphan._id;

          // Save a new Kart
          agent.post('/api/karts')
            .send(kart)
            .expect(200)
            .end(function (kartSaveErr, kartSaveRes) {
              // Handle Kart save error
              if (kartSaveErr) {
                return done(kartSaveErr);
              }

              // Set assertions on new Kart
              (kartSaveRes.body.name).should.equal(kart.name);
              should.exist(kartSaveRes.body.user);
              should.equal(kartSaveRes.body.user._id, orphanId);

              // force the Kart to have an orphaned user reference
              orphan.remove(function () {
                // now signin with valid user
                agent.post('/api/auth/signin')
                  .send(credentials)
                  .expect(200)
                  .end(function (err, res) {
                    // Handle signin error
                    if (err) {
                      return done(err);
                    }

                    // Get the Kart
                    agent.get('/api/karts/' + kartSaveRes.body._id)
                      .expect(200)
                      .end(function (kartInfoErr, kartInfoRes) {
                        // Handle Kart error
                        if (kartInfoErr) {
                          return done(kartInfoErr);
                        }

                        // Set assertions
                        (kartInfoRes.body._id).should.equal(kartSaveRes.body._id);
                        (kartInfoRes.body.name).should.equal(kart.name);
                        should.equal(kartInfoRes.body.user, undefined);

                        // Call the assertion callback
                        done();
                      });
                  });
              });
            });
        });
    });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Kart.remove().exec(done);
    });
  });
});
