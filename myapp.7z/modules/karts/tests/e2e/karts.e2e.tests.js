'use strict';

describe('Karts E2E Tests:', function () {
  describe('Test Karts page', function () {
    it('Should report missing credentials', function () {
      browser.get('http://localhost:3001/karts');
      expect(element.all(by.repeater('kart in karts')).count()).toEqual(0);
    });
  });
});
