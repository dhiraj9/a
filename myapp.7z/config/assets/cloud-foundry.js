'use strict';

module.exports = {};
